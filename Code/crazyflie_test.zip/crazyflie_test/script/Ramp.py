#!/usr/bin/env python
# 15 Nov 2021 - Lorenzo Pichierri

import rospy
from geometry_msgs.msg import Twist

def ramp():
    rospy.init_node('ramp', anonymous=True)

    agent_name = rospy.get_param('~agent_name')
    frequency = rospy.get_param('~controlFreq')
    pub = rospy.Publisher('/{}/cmd_vel'.format(agent_name), Twist, queue_size=10)

    rate = rospy.Rate(frequency) # 100hz
    msgC = Twist()
    while not rospy.is_shutdown():
        msgC.linear.y = 0.0 # [deg/s]
        msgC.linear.x = 0.0
        msgC.angular.z = 0.0
        msgC.linear.z = 10000
        rospy.loginfo(msgC)
        pub.publish(msgC)
        rate.sleep()

if __name__ == '__main__':
    try:
        ramp()

    except rospy.ROSInterruptException:
        pass