#!/usr/bin/env python
# 15 Nov 2021 - Lorenzo Pichierri

import rospy
from geometry_msgs.msg import Twist

def callback(msg):
    rospy.loginfo("Received a /cmd_vel message!")
    rospy.loginfo("Linear Components: [%f, %f, %f]"%(msg.linear.x, msg.linear.y, msg.linear.z))
    rospy.loginfo("Angular Components: [%f, %f, %f]"%(msg.angular.x, msg.angular.y, msg.angular.z))

def listener():
    rospy.init_node('crazyplot')
    agent = rospy.get_param('~agent')
    rospy.Subscriber('/c{}/cmd_vel'.format(agent), Twist, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()