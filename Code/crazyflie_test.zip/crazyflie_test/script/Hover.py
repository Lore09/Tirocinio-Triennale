#!/usr/bin/env python

import rospy
from std_srvs.srv import Empty

import signal
import sys

def handler(signum, frame):
    print("\n!!!EMERGENCY LANDING!!!")
    controller._land()
    sys.exit(0)

class Controller():
    def __init__(self):
        print("init")
        rospy.loginfo("waiting for land service")
        rospy.wait_for_service('land')
        rospy.loginfo("found land service")
        self._land = rospy.ServiceProxy('land', Empty)

        rospy.loginfo("waiting for takeoff service")
        rospy.wait_for_service('takeoff')
        rospy.loginfo("found takeoff service")
        self._takeoff = rospy.ServiceProxy('takeoff', Empty)
    



if __name__ == '__main__':
    rospy.init_node('hover', anonymous=True)
    signal.signal(signal.SIGINT, handler)

    controller = Controller()

    print("wait...")
    rospy.sleep(5)
    print("GOOO!!!")

    try:
        controller._takeoff()
        rospy.sleep(30)
        controller._land()

    except rospy.ROSInterruptException:
        pass
        
