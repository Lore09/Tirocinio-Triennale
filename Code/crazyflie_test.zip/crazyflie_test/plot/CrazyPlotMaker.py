from numpy.core.fromnumeric import size
import pandas as pd
from mpl_toolkits import mplot3d
# from scipy.interpolate import interp1d
import numpy as np
import matplotlib.pyplot as plt
from math import pi, sqrt
import shutil
from matplotlib2tikz import save as tikz_save


def moving_average(x, w):
    return np.convolve(x, np.ones(w), 'valid') / w

################################################################################
# FILE SETTINGS
################################################################################

# plt.ion() #it makes plt.show() not blocking
# False True
save_fig = True
new = False
comp = False

#fig num    #1    #2    #3    #4    #5    #6
plotfig = [True ,True ,True ,True ,False,False]


path = "/home/lorenzo/Desktop/Thesis_talk/figs/3"
name = "multi_1"
name_txt = path + "/" + name + "_pose_01.txt"

if new:
    text = pd.read_csv('/home/lorenzo/quadrotor_choirbot/agents_pose.txt')
    if save_fig:
        shutil.copyfile('/home/lorenzo/quadrotor_choirbot/agents_pose.txt',name_txt)
else:
    text = pd.read_csv(name_txt)

if comp:
    name2 = "multi_2"
    name2_txt = path + "/" + name2 + "_pose_01.txt"
    text2 = pd.read_csv(name2_txt)


print((np.max(text["t"][:])-text["t"][0])/1000000000)

###############################################################################
N = np.max(text["agent_id"][:])+1
samples = np.size(text["agent_id"][:])
dd = 4 # x,y,z,t
dd_norm = 2 # |pos|,t or |vel|,t
scaling = 0.5
#scaling = 0
r_des = 2
v_des = 0.1
z_des = 0.5
omega = v_des/r_des

theta = np.linspace(0,2*pi,100)

pos0 = [    [-0.5*scaling,-0.5*scaling,z_des],
            [ 0.5*scaling,-0.5*scaling,z_des],
            [ 0.5*scaling, 0.5*scaling,z_des],
            [-0.5*scaling, 0.5*scaling,z_des],
            [ 0.0, 0.0,z_des] ]

pos = np.zeros((N,dd,samples))  # position vector x,y,z
vel = np.zeros((N,dd,samples))  # position vector x,y,z
r = np.zeros((N,dd_norm,samples))  # 2D norm position
v_mod = np.zeros((N,dd_norm,samples))  # 3D norm velocity
index =np.zeros(N).astype(int)

sec = pow(10,-9) # seconds
round_val = 4

for i in range(samples):
    agent_id = text["agent_id"][i]
    j = index[agent_id]
    pos[agent_id][0][j] = text["px"][i]
    pos[agent_id][1][j] = text["py"][i]
    pos[agent_id][2][j] = text["pz"][i]
    pos[agent_id][3][j] = round((text["t"][i]-text["t"][0])*sec,round_val)
    vel[agent_id][0][j] = text["vx"][i]
    vel[agent_id][1][j] = text["vy"][i]
    vel[agent_id][2][j] = text["vz"][i]
    vel[agent_id][3][j] = pos[agent_id][3][j]
    r[agent_id][0][j] = np.linalg.norm(np.array([pos[agent_id][0][j],pos[agent_id][1][j]]) - np.array([pos0[agent_id][0],pos0[agent_id][1]]))
    r[agent_id][1][j] = pos[agent_id][3][j]
    v_mod[agent_id][0][j] = np.linalg.norm(np.array([vel[agent_id][0][j],vel[agent_id][1][j]]))
    v_mod[agent_id][1][j] = pos[agent_id][3][j]
    index[agent_id] += 1

min_index = np.min(index)

pos = np.delete(pos,range(min_index,samples), axis=2)
vel = np.delete(vel,range(min_index,samples), axis=2)
r = np.delete(r,range(min_index,samples), axis=2)
v_mod = np.delete(v_mod,range(min_index,samples), axis=2)

sample_max_array = np.zeros(N)  # position vector x,y,z
for i in range(N):
    sample_max_array[i] = np.max(pos[i][3][:])

sample_max = np.min(sample_max_array)
print(samples)
print(sample_max)
print(index)

###############################################################################
# IF COMPARISON:
if comp:
    samples2 = np.size(text2["agent_id"][:])
    pos2 = np.zeros((N,dd,samples2))  # position vector x,y,z
    index2 =np.zeros(N).astype(int)

    for i in range(samples2):
        agent_id = text2["agent_id"][i]
        j = index2[agent_id]
        pos2[agent_id][0][j] = text2["px"][i]
        pos2[agent_id][1][j] = text2["py"][i]
        pos2[agent_id][2][j] = text2["pz"][i]
        pos2[agent_id][3][j] = round((text2["t"][i]-text2["t"][0])*sec,round_val)
        index2[agent_id] += 1

    min_index2 = np.min(index2)

    pos2 = np.delete(pos2,range(min_index2,samples2), axis=2)

    sample_max_array2 = np.zeros(N+1)  # position vector x,y,z
    for i in range(N):
        sample_max_array2[i] = np.max(pos2[i][3][:])
    sample_max_array2[N] = sample_max

    sample_max = np.min(sample_max_array2)

    print(samples2)
    print(sample_max_array2)
    print(sample_max)
    print(index2)

###############################################################################

blueChoiR = '#002945'
redChoiR = '#7f0000'
yellowChoiR = '#f0e62e'
orangeChoiR = '#e68600'
greenChoiR = '#00640a'


colors = [blueChoiR,redChoiR, yellowChoiR, orangeChoiR ,greenChoiR]
markers = ['.','.','.','.','*']
linestyles = ['solid','solid', 'solid','solid', 'dashed']
linewidths = [1.2,1.2,1.2,1.2,0.6]
linewidths = [2,2,2,2,0.6]

labels = ['Drone #1','Drone #2', 'Drone #3','Drone #4', 'Centroide']

###############################
# PLOT XYZ
###############################
if plotfig[0]:
    fig1 = plt.figure()
    plot1 = plt.gca(projection='3d')

    for i in range(N):
        xline = pos[i][0][:]
        yline = pos[i][1][:]
        zline = pos[i][2][:]
        plot1.plot3D(xline, yline, zline, color=colors[i],linestyle=linestyles[i],linewidth=linewidths[i], label=labels[i])

        xcircle = r_des*np.cos(theta) + pos0[i][0]
        ycircle = r_des*np.sin(theta) + pos0[i][1]
        zcircle = pos0[i][2]
        plot1.plot3D(xcircle, ycircle,zcircle,color='grey',linestyle='dashed', linewidth=0.2)

        xpoint = pos0[i][0]
        ypoint = pos0[i][1]
        zpoint = pos0[i][2]
        plot1.scatter(xpoint, ypoint, zpoint, color=colors[i],marker=markers[i],linewidth=linewidths[i])

    plot1.set_aspect('equal')
    plot1.set_title('XYZ Trajectory')
    plot1.set_xlabel('x position $[m]$')
    plot1.set_ylabel('y position $[m]$')
    plot1.set_zlabel('z position $[m]$')
    plot1 = plt.grid(color='grey', linestyle='-', linewidth=0.2, alpha = 0.2)
    # plot1 = plt.gca().legend()

    name_save     = path + "/" + name + "_3D_traj" + ".pdf"

    if save_fig:
        fig1 = plt.savefig(name_save)


###############################
# PLOT XY
###############################
if plotfig[1]:
    fig2, ax2 = plt.subplots()
    for i in range(N):
        xcircle = r_des*np.cos(theta) + pos0[i][0]
        ycircle = r_des*np.sin(theta) + pos0[i][1]
        plot2 = plt.plot(xcircle, ycircle, color='grey',linestyle='dashed', linewidth=0.2)

        xline = pos[i][0][:]
        yline = pos[i][1][:]
        plot2 = plt.plot(xline, yline, color=colors[i],linestyle=linestyles[i], linewidth=linewidths[i],label=labels[i])
        
        xpoint = pos0[i][0]
        ypoint = pos0[i][1]
        plot2 = plt.plot(xpoint, ypoint, color=colors[i], marker=markers[i], linewidth=linewidths[i])

    plot2 = plt.axis('equal')
    plot2 = plt.grid(color='grey', linestyle='-', linewidth=0.2, alpha = 0.2)
    ax2.set(title='XY Trajectory',
            xlabel='x position $[m]$', 
            ylabel='y position $[m]$')
    # plot2 = plt.gca().legend()

    name_save = path + "/" + name + "_xy_traj" + ".pdf"

    if save_fig:
        fig2 = plt.savefig(name_save)


###############################
# RADIUS PLOT
###############################
if plotfig[2]:
    fig3, ax3 = plt.subplots()
    for i in range(N):
        tline = r[i][1][:]
        xline = (r[i][0][:]-r_des)/r_des
        # xline = abs(xline)   
        plot3 = plt.plot(tline, xline, color=colors[i],linestyle=linestyles[i], linewidth=linewidths[i], label=labels[i])

    ax3.set(title='Radius Error',
            xlabel='Time $[s]$', 
            ylabel='Radius $[m]$',
            xlim = [0,sample_max],
            ylim = [-1.05, 1.05])

    ax3.axhline(y=0, color='gray', linewidth=0.5)
    plot3 = plt.grid(color='grey', linestyle='-', linewidth=0.2, alpha = 0.2)
    # plot3 = plt.gca().legend()
    name_save = path + "/" + name + "_r_err" + ".pdf"
    if save_fig:
        fig3 = plt.savefig(name_save)


###############################
# VEL_TANG PLOT
###############################
if plotfig[3]:
    fig4, ax4 = plt.subplots()
    for i in range(N): 
        tline = v_mod[i][1][:]
        vline = (v_mod[i][0][:]-v_des)/v_des
        # vline = abs(vline)
        plot4 = plt.plot(tline, vline, color=colors[i],linestyle=linestyles[i], linewidth=linewidths[i], label=labels[i])



    ax4.set(title='Tangential Velocity Error',
            xlabel='Time $[s]$', 
            ylabel='Velocity $[m s^{-1}]$',
            xlim = [0,sample_max],
            ylim = [-1.05, 1.05])

    ax4.axhline(y=0, color='gray', linewidth=0.5)
    plot4 = plt.grid(color='grey', linestyle='-', linewidth=0.2, alpha = 0.2)
    plot4 = plt.gca().legend(prop={"size":12})
    name_save = path + "/" + name + "_v_err" + ".pdf"
    if save_fig:
        fig4 = plt.savefig(name_save)

###############################
# COORDINATION : COMPUTATIONS
###############################
if plotfig[4] or plotfig[5]:
    #yval = scaling*0.5
    gran = 10
    pos_sync = np.zeros((N,dd,gran*min_index))
    form_diag = np.zeros((2,gran*min_index))
    leaders_sync = np.zeros(gran*min_index)

    for i in range(N):
        for t in range(0,min_index):
            for d in range(0,gran):
                if (pos[i][3][t] - int(pos[i][3][t])) <= d/gran :
                    pos_sync[i][0][int(pos[i][3][t])*gran+d] = pos[i][0][t]
                    pos_sync[i][1][int(pos[i][3][t])*gran+d] = pos[i][1][t]
                    pos_sync[i][2][int(pos[i][3][t])*gran+d] = pos[i][2][t]
                    pos_sync[i][3][int(pos[i][3][t])*gran+d] = int(pos[i][3][t]) + d/gran
                

    for i in range(N):
        for t in range(0,gran*min_index):
            for d in range(0,dd):
                if not pos_sync[i][d][t]:
                    pos_sync[i][d][t] = pos_sync[i][d][t-1]


    for t in range(0,gran*min_index):
        form_diag[0][t] = np.linalg.norm(np.array([pos_sync[0][0][t],pos_sync[0][1][t]]) - np.array([pos_sync[2][0][t],pos_sync[2][1][t]]))
        form_diag[1][t] = np.linalg.norm(np.array([pos_sync[1][0][t],pos_sync[1][1][t]]) - np.array([pos_sync[3][0][t],pos_sync[3][1][t]]))
        leaders_sync[t] = pos_sync[0][1][t]-pos_sync[1][1][t]

    if comp:
        pos_sync2 = np.zeros((N,dd,gran*min_index2))
        form_diag2 = np.zeros((2,gran*min_index2))
        leaders_sync2 = np.zeros(gran*min_index2)

        for i in range(N):
            for t in range(0,min_index2):
                for d in range(0,gran):
                    if (pos2[i][3][t] - int(pos2[i][3][t])) <= d/gran :
                        pos_sync2[i][0][int(pos2[i][3][t])*gran+d] = pos2[i][0][t]
                        pos_sync2[i][1][int(pos2[i][3][t])*gran+d] = pos2[i][1][t]
                        pos_sync2[i][2][int(pos2[i][3][t])*gran+d] = pos2[i][2][t]
                        pos_sync2[i][3][int(pos2[i][3][t])*gran+d] = int(pos2[i][3][t]) + d/gran


        for i in range(N):
            for t in range(0,gran*min_index2):
                for d in range(0,dd):
                    if not pos_sync2[i][d][t]:
                        pos_sync2[i][d][t] = pos_sync2[i][d][t-1]

        for t in range(0,gran*min_index2):
            form_diag2[0][t] = np.linalg.norm(np.array([pos_sync2[0][0][t],pos_sync2[0][1][t]]) - np.array([pos_sync2[2][0][t],pos_sync2[2][1][t]]))
            form_diag2[1][t] = np.linalg.norm(np.array([pos_sync2[1][0][t],pos_sync2[1][1][t]]) - np.array([pos_sync2[3][0][t],pos_sync2[3][1][t]]))
            leaders_sync2[t] = pos_sync2[0][1][t]-pos_sync2[1][1][t]

###############################
# COORDINATION : PLOT 5 - FORMATION ERROR
###############################
if plotfig[4]:
    w = 100 # moving average window
    fig5, ax5 = plt.subplots()
    i = 0

    # tline = pos_sync[i][3][:gran*min_index - w + 1]
    tline = pos_sync[i][3][w - 1:]
    vline = moving_average(form_diag[0][:]*form_diag[1][:]*0.5 - scaling*scaling,w)
    plot5 = plt.plot(tline, vline, color=colors[0],linestyle=linestyles[i], linewidth=linewidths[i])

    # MOVING AVERAGE
    # w=100
    # pos_sync_w = np.zeros(gran*min_index- w + 1)
    # pos_sync_w = moving_average(pos_sync[0][0][:],w)
    # tline = pos_sync[i][3][w*0.5-1:]
    # vline = pos_sync_w[:]
    # plot5 = plt.plot(tline, vline, color='red',linestyle='dashed', linewidth=linewidths[i])

    if comp:
        print(comp)
        # tline = pos_sync2[i][3][:gran*min_index2 - w + 1]
        tline = pos_sync2[i][3][w - 1:]
        vline = moving_average(form_diag2[0][:]*form_diag2[1][:]*0.5 - scaling*scaling,w)
        # vline = pos_sync2[i][0][:]

        plot5 = plt.plot(tline, vline, color=colors[1],linestyle=linestyles[i], linewidth=linewidths[i])
        plt.gca().legend(('without SR','with SR'), prop={"size":15})

    ax5.set(title='Formation Error',
            xlabel='Time $[s]$', 
            ylabel='Area $[m^2]$',
            # xlim = [0,sample_max])
            xlim = [0,sample_max],
            ylim = [-1.1,1.1])

    plot5 = plt.grid(color='grey', linestyle='-', linewidth=0.2, alpha = 0.2)
    ax5.axhline(y=0, color='gray', linewidth=0.5)
    if save_fig:
        name_save = path + "/" + name + "_form_err" + ".pdf"
        if comp:
            name_save = path + "/" + name + "_vs_" + name2 + "_form_err" + ".pdf"
        fig5 = plt.savefig(name_save)

###############################
# COORDINATION : PLOT 6 - SYNC ERROR
###############################

if plotfig[5]:
    w = 100 # moving average window
    fig6, ax6 = plt.subplots()
    i = 0
    # tline = pos_sync[i][3][:gran*min_index - w + 1]
    tline = pos_sync[i][3][w - 1:]

    vline = moving_average(leaders_sync[:],w)
    plot6 = plt.plot(tline, vline, color=colors[0],linestyle=linestyles[i], linewidth=linewidths[i])
    if comp:
        print(comp)
        tline = pos_sync2[i][3][w - 1:]
        # tline = pos_sync2[i][3][:gran*min_index2 - w + 1]
        vline = moving_average(leaders_sync2[:],w)
        plot6 = plt.plot(tline, vline, color=colors[1],linestyle=linestyles[i], linewidth=linewidths[i])
        #plt.gca().legend(('Simulation #1','Simulation #2'))

    ax6.set(title='Latitude Error',
            xlabel='Time $[s]$', 
            ylabel='$y_{L1} - y_{L2}$ $[m]$',
            # xlim = [0,sample_max])
            xlim = [0,sample_max],
            ylim = [-0.7,0.7])

    plot6 = plt.grid(color='grey', linestyle='-', linewidth=0.2, alpha = 0.2)
    ax6.axhline(y=0, color='gray', linewidth=0.5)
    if save_fig:
        name_save = path + "/" + name + "_sync_err" + ".pdf"
        if comp:
            name_save = path + "/" + name + "_vs_" + name2 + "_sync_err" + ".pdf"
        fig6 = plt.savefig(name_save)


###############################

plt.show()





